package com.example.dsdbluetoothtest;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.UUID;

import static android.telecom.Call.STATE_DISCONNECTED;

public class MainActivity extends AppCompatActivity {

    private static final long SCAN_PERIOD = 10000;
    private BluetoothAdapter bluetoothAdapter;
    private DeviceDTO _dsdDevice;
    private String mDeviceAddress;

    private boolean mScanning;
    private Handler mHandler;
    private int REQUEST_ENABLE_BT=10;
    private String TAG="Main Activity";
    private String message;
    private boolean messageSent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        _dsdDevice = new DeviceDTO();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter= BluetoothAdapter.getDefaultAdapter();

        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();

        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);

        }

        messageSent=false;
        message="";
        scanLeDevice(true);
    }

    @Override
    protected  void onResume(){
        super.onResume();
    }

    private void scanLeDevice(final boolean enable) {
        if (enable) {
            mScanning = true;
            bluetoothAdapter.startLeScan(mLeScanCallback);
        } else {
            mScanning = false;
            bluetoothAdapter.stopLeScan(mLeScanCallback);

            _dsdDevice.getDevice().connectGatt(this,false,gattCallback);

        }
    }

    public void OpenDoor(View view){
        scanLeDevice(false);
        message="OPEN";
        scanLeDevice(true);

    }

    public void CloseDoor(View view){
        scanLeDevice(false);
        message="CLOSE";
        scanLeDevice(true);
    }


    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {

                @Override
                public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String deviceName=device.getName();

                            if(deviceName!=null && deviceName.equals("DSD TECH")) {
                                _dsdDevice.setDevice(device);
                                scanLeDevice(false);
                            }
                        }
                    });
                }
            };

    @Override
    protected void onDestroy() { super.onDestroy(); }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }



    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "com.example.bluetooth.le.EXTRA_DATA";

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);
    }



    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        private int mConnectionState = STATE_DISCONNECTED;
        private String TAG="Gatt Callback";
        private UUID _service_uuid=UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
        private UUID _characteristic_uuid=UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");



        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                intentAction = ACTION_GATT_CONNECTED;
                broadcastUpdate(intentAction);
                Log.i(TAG, "Connected to GATT server.");
                // Attempts to discover services after successful connection.
                Log.i(TAG, "Attempting to start service discovery:" +
                        gatt.discoverServices());
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                intentAction = ACTION_GATT_DISCONNECTED;
                mConnectionState = STATE_DISCONNECTED;
                Log.i(TAG, "Disconnected from GATT server.");
                broadcastUpdate(intentAction);
                messageSent=false;
                gatt.disconnect();
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                List<BluetoothGattService> gattServices = gatt.getServices();
                for (BluetoothGattService gattService : gattServices) {
                    Log.i(TAG, "Service UUID Found: " + gattService.getUuid().toString());
                }
                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                sendMessage(gatt);
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG,"Here");
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
//            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
        }

        private void sendMessage(BluetoothGatt gatt){
            if(!messageSent) {
                try {
                    BluetoothGattService serv = gatt.getService(_service_uuid);

                    BluetoothGattCharacteristic bgc = serv.getCharacteristic(_characteristic_uuid);

                    bgc.setValue(message+"\n");
                    gatt.writeCharacteristic(bgc);
                } catch (Exception e) {
                    Log.e("GATT", e.toString());
                }
                messageSent=true;
            }
            gatt.disconnect();

            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    CharSequence _messageSentChar = "Message Sent!";
                    Toast.makeText(getApplicationContext(),_messageSentChar,5).show();
                }
            });
        }
    };



}
