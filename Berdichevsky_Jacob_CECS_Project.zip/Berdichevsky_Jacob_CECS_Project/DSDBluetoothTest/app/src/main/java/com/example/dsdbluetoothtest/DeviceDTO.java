package com.example.dsdbluetoothtest;

import android.bluetooth.BluetoothDevice;

public class DeviceDTO {
    private BluetoothDevice _device;
    public DeviceDTO(){}

    public void setDevice(BluetoothDevice device){
        this._device=device;
    }
    public BluetoothDevice getDevice(){
        return this._device;
    }

}
